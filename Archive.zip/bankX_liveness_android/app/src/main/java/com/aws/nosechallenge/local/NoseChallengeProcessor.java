/**********************************************************************************************************************
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.                                            *
 *                                                                                                                    *
 * Licensed under the Amazon Software License (the "License"). You may not use this file except in compliance         *
 * with the License. A copy of the License is located at                                                              *
 *                                                                                                                    *
 *     http://aws.amazon.com/asl/                                                                                     *
 *                                                                                                                    *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES  *
 * OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions     *
 * and limitations under the License.                                                                                 *
 **********************************************************************************************************************/

package com.aws.nosechallenge.local;

import android.graphics.Bitmap;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;

import com.aws.nosechallenge.common.FrameMetadata;
import com.aws.nosechallenge.common.GraphicOverlay;
import com.aws.nosechallenge.common.ProcessorBase;
import com.aws.nosechallenge.local.states.StateManager;
import com.google.android.gms.tasks.Task;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.face.FirebaseVisionFace;
import com.google.firebase.ml.vision.face.FirebaseVisionFaceDetector;
import com.google.firebase.ml.vision.face.FirebaseVisionFaceDetectorOptions;

import java.io.IOException;
import java.util.List;

public class NoseChallengeProcessor extends ProcessorBase<List<FirebaseVisionFace>> {

    private static final String LOG_TAG = "Nose/NoseProcessor";

    private final FirebaseVisionFaceDetector detector;
    private final StateManager stateManager;
    private final OnLocalChallengeCallback onLocalChallengeCallback;

    private boolean challengeComplete = false;

    public NoseChallengeProcessor(ViewBinding binding, OnLocalChallengeCallback onLocalChallengeCallback) {
        this.onLocalChallengeCallback = onLocalChallengeCallback;
        FirebaseVisionFaceDetectorOptions options =
                new FirebaseVisionFaceDetectorOptions.Builder()
                        .setLandmarkMode(FirebaseVisionFaceDetectorOptions.ALL_LANDMARKS)
                        .enableTracking()
                        .build();
        detector = FirebaseVision.getInstance().getVisionFaceDetector(options);
        stateManager = new StateManager(binding);
    }

    @Override
    public void stop() {
        try {
            detector.close();
        } catch (IOException e) {
            Log.e(LOG_TAG, "Exception thrown while trying to close Face Detector: " + e);
        }
    }

    @Override
    protected Task<List<FirebaseVisionFace>> detectInImage(FirebaseVisionImage image) {
        return detector.detectInImage(image);
    }

    @Override
    protected void onSuccess(
            @Nullable Bitmap originalCameraImage,
            @NonNull List<FirebaseVisionFace> faces,
            @NonNull FrameMetadata frameMetadata,
            @NonNull GraphicOverlay graphicOverlay) {
        graphicOverlay.clear();
        if (originalCameraImage != null) {
            GraphicOverlay.Graphic graphic = stateManager.process(originalCameraImage, faces, graphicOverlay);
            graphicOverlay.add(graphic);
            if (!challengeComplete && stateManager.isDone()) {
                challengeComplete = true;
                if (stateManager.isSuccess()) {
                    onLocalChallengeCallback.onLocalChallengeSuccess(stateManager.getFrames());
                } else {
                    onLocalChallengeCallback.onLocalChallengeFail();
                }
            }
        }
        graphicOverlay.postInvalidate();
    }

    @Override
    protected void onFailure(@NonNull Exception e) {
        Log.e(LOG_TAG, "Face detection failed " + e);
    }
}
