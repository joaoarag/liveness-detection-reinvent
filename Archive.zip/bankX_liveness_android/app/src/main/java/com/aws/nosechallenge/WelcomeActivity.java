/**********************************************************************************************************************
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.                                            *
 *                                                                                                                    *
 * Licensed under the Amazon Software License (the "License"). You may not use this file except in compliance         *
 * with the License. A copy of the License is located at                                                              *
 *                                                                                                                    *
 *     http://aws.amazon.com/asl/                                                                                     *
 *                                                                                                                    *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES  *
 * OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions     *
 * and limitations under the License.                                                                                 *
 **********************************************************************************************************************/

package com.aws.nosechallenge;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.aws.nosechallenge.databinding.ActivityWelcomeBinding;
import com.aws.nosechallenge.remote.GetChallengeDetailsTask;
import com.aws.nosechallenge.remote.OnChallengeDetailsCallback;
import com.google.firebase.crashlytics.FirebaseCrashlytics;

import java.util.ArrayList;
import java.util.List;


public class WelcomeActivity extends AppCompatActivity implements
        ActivityCompat.OnRequestPermissionsResultCallback, View.OnClickListener, OnChallengeDetailsCallback {

    private static final String LOG_TAG = "Nose/WelcomeActivity";

    private static final int PERMISSION_REQUESTS = 1;

    private ActivityWelcomeBinding activityWelcomeBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityWelcomeBinding = ActivityWelcomeBinding.inflate(getLayoutInflater());
        setContentView(activityWelcomeBinding.getRoot());
        activityWelcomeBinding.startButton.setOnClickListener(this);

        // Just for fun :)
        activityWelcomeBinding.welcomeAnimation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activityWelcomeBinding.welcomeAnimation.playAnimation();
            }
        });

        if (!allPermissionsGranted()) {
            activityWelcomeBinding.startButton.setEnabled(false);
            getRuntimePermissions();
        }

        // Crashlytics
        FirebaseCrashlytics.getInstance().setUserId(MyApplication.USER_ID);
    }

    private String[] getRequiredPermissions() {
        try {
            PackageInfo info =
                    this.getPackageManager()
                            .getPackageInfo(this.getPackageName(), PackageManager.GET_PERMISSIONS);
            String[] ps = info.requestedPermissions;
            if (ps != null && ps.length > 0) {
                return ps;
            } else {
                return new String[0];
            }
        } catch (Exception e) {
            return new String[0];
        }
    }

    private boolean allPermissionsGranted() {
        for (String permission : getRequiredPermissions()) {
            if (!isPermissionGranted(this, permission)) {
                return false;
            }
        }
        return true;
    }

    private void getRuntimePermissions() {
        List<String> allNeededPermissions = new ArrayList<>();
        for (String permission : getRequiredPermissions()) {
            if (!isPermissionGranted(this, permission)) {
                allNeededPermissions.add(permission);
            }
        }

        if (!allNeededPermissions.isEmpty()) {
            ActivityCompat.requestPermissions(
                    this, allNeededPermissions.toArray(new String[0]), PERMISSION_REQUESTS);
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        Log.i(LOG_TAG, "Permission granted!");
        if (allPermissionsGranted()) {
            activityWelcomeBinding.startButton.setEnabled(true);
        } else {
            String errorMessage = getString(R.string.permissions_error);
            Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show();
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private static boolean isPermissionGranted(Context context, String permission) {
        if (ContextCompat.checkSelfPermission(context, permission)
                == PackageManager.PERMISSION_GRANTED) {
            Log.i(LOG_TAG, "Permission granted: " + permission);
            return true;
        }
        Log.i(LOG_TAG, "Permission NOT granted: " + permission);
        return false;
    }

    @Override
    public void onClick(View v) {
        activityWelcomeBinding.startButton.setText(getString(R.string.start_button_loading));
        activityWelcomeBinding.startButton.setEnabled(false);
        new GetChallengeDetailsTask(this).execute();
    }

    @Override
    public void onChallengeDetailsSuccessCallback(ChallengeDetails challengeDetails) {
        Log.d(LOG_TAG, "Challenge details: " + challengeDetails);

        // Crashlytics
        FirebaseCrashlytics.getInstance().setCustomKey("challengeId", challengeDetails.getId());
        FirebaseCrashlytics.getInstance().log(challengeDetails.toString());

        ((MyApplication) getApplication()).initConfiguration(challengeDetails);
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onChallengeDetailsFailCallback() {
        String errorMessage = getString(R.string.api_error_challenge_details);
        Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show();
        activityWelcomeBinding.startButton.setText(getString(R.string.start_button));
        activityWelcomeBinding.startButton.setEnabled(true);
    }
}
