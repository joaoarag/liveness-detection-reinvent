/**********************************************************************************************************************
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.                                            *
 *                                                                                                                    *
 * Licensed under the Amazon Software License (the "License"). You may not use this file except in compliance         *
 * with the License. A copy of the License is located at                                                              *
 *                                                                                                                    *
 *     http://aws.amazon.com/asl/                                                                                     *
 *                                                                                                                    *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES  *
 * OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions     *
 * and limitations under the License.                                                                                 *
 **********************************************************************************************************************/

package com.aws.nosechallenge;

import android.app.Application;
import android.content.res.Resources;
import android.graphics.Color;

import com.amazonaws.regions.Regions;

import java.util.UUID;


public class MyApplication extends Application {

    // User id (fake here; must be changed accordingly)
    public static final String USER_ID = UUID.randomUUID().toString();

    // AWS backend
    public static final String API_BASE_URL = "https://56j2fmaat0.execute-api.us-east-1.amazonaws.com/prod/challenge/";
    public static final String API_START_ENDPOINT = "start";
    public static final String API_VERIFY_ENDPOINT_PATTERN = "%s/verify";
    public static final String IDENTITY_POOL_ID = "us-east-1:a6b13346-a036-4f0b-99e7-19b30d07c32b";
    public static final String BUCKET_NAME = "rafaelam-liveness";
    public static final Regions AWS_REGION = Regions.US_EAST_1;
    public static final int S3_UPLOAD_TIMEOUT_IN_MINUTES = 1;
    public static final int JPG_QUALITY = 70;

    // Challenge values
    public static final float CAMERA_PREVIEW_REQUESTED_FPS = 28.0f;  // FPS for the preview
    public static final float UPLOAD_MAXIMUM_FPS = 14.0f;  // Limits the number of frames uploaded to the API
    public static final int DESIRED_IMAGE_WIDTH = 240;
    public static final int DESIRED_IMAGE_HEIGHT = 320;

    // Local states' durations (-1 means indefinite)
    // If the user takes more than the duration in a given state, the local challenge fails
    public static final int STATE_FACE_DURATION_IN_SECONDS = -1;
    public static final int STATE_AREA_DURATION_IN_SECONDS = 10;
    public static final int STATE_NOSE_DURATION_IN_SECONDS = 10;
    public static final int STATE_SUCCESS_DURATION_IN_SECONDS = -1;
    public static final int STATE_FAIL_DURATION_IN_SECONDS = -1;

    // Graphics
    // We disabled some graphics to make the challenge smother in low end devices
    public static final boolean SHOW_FACE_BOX = false;  // good for debugging
    public static final boolean SHOW_NOSE_LANDMARK = false;  // set false to increase smoothness "illusion"
    public static final boolean DRAW_TRANSPARENT_BACKGROUND = true;  // set false to increase draw speed
    public static final int NOSE_LANDMARK_RADIUS = 10;  // just used if SHOW_NOSE_LANDMARK is true
    public static final int BACKGROUND_ALPHA = 80;  // just used if DRAW_TRANSPARENT_BACKGROUND is true
    public static final int STROKE_WIDTH = 4;
    public static final int COLOR_FACE_BOX = Color.WHITE;
    public static final int COLOR_NOSE_LANDMARK = Color.RED;
    public static final int COLOR_INSIDE_FACE_AREA = 0xFF4CAF50;
    public static final int COLOR_OUTSIDE_FACE_AREA = 0xFFF44336;
    public static final int COLOR_NOSE_BOX = 0xFFFF9900;


    private static Configuration configuration;

    public void initConfiguration(ChallengeDetails challengeDetails) {
        MyApplication.configuration = new Configuration(getResources(), challengeDetails);
    }

    public static Configuration getConfiguration() {
        if (configuration == null) {
            throw new IllegalStateException("Must init configuration first");
        }
        return configuration;
    }

    public static class Configuration {

        // Messages (defined in XML resources)
        private final String stateAreaMessage;
        private final String stateFaceNoFaceMessage;
        private final String stateFaceMultipleFacesMessage;
        private final String stateNoseMessage;

        // Challenge details (usually from API)
        private final ChallengeDetails challengeDetails;

        private Configuration(Resources resources, ChallengeDetails challengeDetails) {
            stateAreaMessage = resources.getString(R.string.state_area_message);
            stateFaceNoFaceMessage = resources.getString(R.string.state_face_no_face_message);
            stateFaceMultipleFacesMessage = resources.getString(R.string.state_face_multiple_faces_message);
            stateNoseMessage = resources.getString(R.string.state_nose_message);
            this.challengeDetails = challengeDetails;
        }

        public String getStateAreaMessage() {
            return stateAreaMessage;
        }

        public String getStateFaceNoFaceMessage() {
            return stateFaceNoFaceMessage;
        }

        public String getStateFaceMultipleFacesMessage() {
            return stateFaceMultipleFacesMessage;
        }

        public String getStateNoseMessage() {
            return stateNoseMessage;
        }

        public ChallengeDetails getChallengeDetails() {
            return challengeDetails;
        }
    }
}
