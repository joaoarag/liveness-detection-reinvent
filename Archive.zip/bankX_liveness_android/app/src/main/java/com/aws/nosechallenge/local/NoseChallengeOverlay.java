/**********************************************************************************************************************
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.                                            *
 *                                                                                                                    *
 * Licensed under the Amazon Software License (the "License"). You may not use this file except in compliance         *
 * with the License. A copy of the License is located at                                                              *
 *                                                                                                                    *
 *     http://aws.amazon.com/asl/                                                                                     *
 *                                                                                                                    *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES  *
 * OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions     *
 * and limitations under the License.                                                                                 *
 **********************************************************************************************************************/

package com.aws.nosechallenge.local;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.view.View;
import android.widget.TextView;

import androidx.viewbinding.ViewBinding;

import com.airbnb.lottie.LottieAnimationView;
import com.aws.nosechallenge.MyApplication;
import com.aws.nosechallenge.R;
import com.aws.nosechallenge.common.GraphicOverlay;

public class NoseChallengeOverlay extends GraphicOverlay.Graphic {

    private ViewBinding binding;
    private Point noseLandmark;
    private Rect faceAreaBox;
    private Rect noseChallengeBox;
    private String message;
    private Rect faceBox;
    private boolean isInsideFaceArea;
    private boolean showHelpAnimation1;
    private boolean showHelpAnimation2;

    public NoseChallengeOverlay(GraphicOverlay graphicOverlay) {
        super(graphicOverlay);
    }

    @Override
    public void draw(Canvas canvas) {
        if (faceAreaBox != null) {
            if (MyApplication.DRAW_TRANSPARENT_BACKGROUND) {
                Paint backgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                backgroundPaint.setColor(Color.BLACK);
                backgroundPaint.setAlpha(MyApplication.BACKGROUND_ALPHA);
                backgroundPaint.setStyle(Paint.Style.FILL);
                canvas.drawPaint(backgroundPaint);
                backgroundPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
                drawScaledRect(canvas, faceAreaBox, backgroundPaint, true);
            }
            Paint faceAreaBoxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            faceAreaBoxPaint.setColor(isInsideFaceArea ?
                    MyApplication.COLOR_INSIDE_FACE_AREA : MyApplication.COLOR_OUTSIDE_FACE_AREA);
            faceAreaBoxPaint.setStyle(Paint.Style.STROKE);
            faceAreaBoxPaint.setStrokeWidth(MyApplication.STROKE_WIDTH);
            drawScaledRect(canvas, faceAreaBox, faceAreaBoxPaint, true);
        }
        if (noseChallengeBox != null) {
            Paint noseChallengeBoxPaint = new Paint();
            noseChallengeBoxPaint.setColor(MyApplication.COLOR_NOSE_BOX);
            noseChallengeBoxPaint.setStyle(Paint.Style.STROKE);
            noseChallengeBoxPaint.setStrokeWidth(MyApplication.STROKE_WIDTH);
            drawScaledRect(canvas, noseChallengeBox, noseChallengeBoxPaint, false);
        }
        if (MyApplication.SHOW_FACE_BOX && faceBox != null) {
            Paint faceABoxPaint = new Paint();
            faceABoxPaint.setColor(MyApplication.COLOR_FACE_BOX);
            faceABoxPaint.setStyle(Paint.Style.STROKE);
            drawScaledRect(canvas, faceBox, faceABoxPaint, false);
        }
        if (MyApplication.SHOW_NOSE_LANDMARK && noseLandmark != null) {
            Paint noseLandmarkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            noseLandmarkPaint.setColor(MyApplication.COLOR_NOSE_LANDMARK);
            float x = translateX(noseLandmark.x);
            float y = translateY(noseLandmark.y);
            canvas.drawCircle(x, y, MyApplication.NOSE_LANDMARK_RADIUS, noseLandmarkPaint);
        }

        if (message != null) {
            TextView textView = binding.getRoot().findViewById(R.id.infoText);
            textView.setText(message);
        }

        // Code should be improved
        LottieAnimationView helpAnimation1 = binding.getRoot().findViewById(R.id.help_animation1);
        int helpAnimation1Visibility = showHelpAnimation1 ? View.VISIBLE : View.GONE;
        helpAnimation1.setVisibility(helpAnimation1Visibility);
        LottieAnimationView helpAnimation2 = binding.getRoot().findViewById(R.id.help_animation2);
        int helpAnimation2Visibility = showHelpAnimation2 ? View.VISIBLE : View.GONE;
        helpAnimation2.setVisibility(helpAnimation2Visibility);
    }

    private void drawScaledRect(Canvas canvas, Rect rect, Paint paint, boolean oval) {
        float left = scaleX(rect.left);
        float top = scaleY(rect.top);
        float right = scaleX(rect.right);
        float bottom = scaleY(rect.bottom);
        if (oval) {
            canvas.drawOval(left, top, right, bottom, paint);
        } else {
            canvas.drawRect(left, top, right, bottom, paint);
        }
    }

    public void setBinding(ViewBinding binding) {
        this.binding = binding;
    }

    public void setNoseLandmark(Point noseLandmark) {
        this.noseLandmark = noseLandmark;
    }

    public void setFaceAreaBox(Rect faceAreaBox) {
        this.faceAreaBox = faceAreaBox;
    }

    public void setNoseChallengeBox(Rect noseChallengeBox) {
        this.noseChallengeBox = noseChallengeBox;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setInsideFaceArea(boolean insideFaceArea) {
        isInsideFaceArea = insideFaceArea;
    }

    public void setFaceBox(Rect faceBox) {
        this.faceBox = faceBox;
    }

    public void setShowHelpAnimation1(boolean showHelpAnimation1) {
        this.showHelpAnimation1 = showHelpAnimation1;
    }

    public void setShowHelpAnimation2(boolean showHelpAnimation2) {
        this.showHelpAnimation2 = showHelpAnimation2;
    }
}
