/**********************************************************************************************************************
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.                                            *
 *                                                                                                                    *
 * Licensed under the Amazon Software License (the "License"). You may not use this file except in compliance         *
 * with the License. A copy of the License is located at                                                              *
 *                                                                                                                    *
 *     http://aws.amazon.com/asl/                                                                                     *
 *                                                                                                                    *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES  *
 * OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions     *
 * and limitations under the License.                                                                                 *
 **********************************************************************************************************************/

package com.aws.nosechallenge.local.states;

import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

import com.aws.nosechallenge.MyApplication;
import com.aws.nosechallenge.common.GraphicOverlay;
import com.aws.nosechallenge.local.NoseChallengeOverlay;
import com.google.firebase.ml.vision.face.FirebaseVisionFace;

import java.util.List;

public class AreaState extends State {

    private static final String NAME = "Area";

    private final int faceTrackingId;

    AreaState(ViewBinding binding, int faceTrackingId) {
        super(binding);
        this.faceTrackingId = faceTrackingId;
    }

    @Override
    public Result process(@NonNull List<FirebaseVisionFace> faces, @NonNull GraphicOverlay graphicOverlay) {
        NoseChallengeOverlay noseChallengeOverlay = new NoseChallengeOverlay(graphicOverlay);
        noseChallengeOverlay.setBinding(getBinding());
        noseChallengeOverlay.setFaceAreaBox(getFaceAreaBox());
        noseChallengeOverlay.setShowHelpAnimation1(true);
        if (faces.size() == 1) {
            FirebaseVisionFace face = faces.get(0);
            if (faceTrackingId == face.getTrackingId()) {
                noseChallengeOverlay.setFaceBox(face.getBoundingBox());
                if (getFaceAreaBox().contains(face.getBoundingBox())) {  // Success
                    return new Result(noseChallengeOverlay, new NoseState(getBinding(), faceTrackingId));
                }
                noseChallengeOverlay.setMessage(MyApplication.getConfiguration().getStateAreaMessage());
                return new Result(noseChallengeOverlay, this);
            }
        }
        return new Result(noseChallengeOverlay, new FailState(getBinding()));
    }

    @Override
    public int getMaximumDurationInSeconds() {
        return MyApplication.STATE_AREA_DURATION_IN_SECONDS;
    }

    @Override
    String getName() {
        return NAME;
    }
}
