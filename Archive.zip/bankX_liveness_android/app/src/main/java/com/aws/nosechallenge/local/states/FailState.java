/**********************************************************************************************************************
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.                                            *
 *                                                                                                                    *
 * Licensed under the Amazon Software License (the "License"). You may not use this file except in compliance         *
 * with the License. A copy of the License is located at                                                              *
 *                                                                                                                    *
 *     http://aws.amazon.com/asl/                                                                                     *
 *                                                                                                                    *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES  *
 * OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions     *
 * and limitations under the License.                                                                                 *
 **********************************************************************************************************************/

package com.aws.nosechallenge.local.states;

import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

import com.aws.nosechallenge.MyApplication;
import com.aws.nosechallenge.common.GraphicOverlay;
import com.aws.nosechallenge.local.NoseChallengeOverlay;
import com.google.firebase.ml.vision.face.FirebaseVisionFace;

import java.util.List;

public class FailState extends State {

    static final String NAME = "Fail";

    FailState(ViewBinding binding) {
        super(binding);
    }

    @Override
    public Result process(@NonNull List<FirebaseVisionFace> faces, @NonNull GraphicOverlay graphicOverlay) {
        NoseChallengeOverlay noseChallengeOverlay = new NoseChallengeOverlay(graphicOverlay);
        noseChallengeOverlay.setBinding(getBinding());
        return new Result(noseChallengeOverlay, this);
    }

    @Override
    public int getMaximumDurationInSeconds() {
        return MyApplication.STATE_FAIL_DURATION_IN_SECONDS;
    }

    @Override
    String getName() {
        return NAME;
    }
}
