/**********************************************************************************************************************
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.                                            *
 *                                                                                                                    *
 * Licensed under the Amazon Software License (the "License"). You may not use this file except in compliance         *
 * with the License. A copy of the License is located at                                                              *
 *                                                                                                                    *
 *     http://aws.amazon.com/asl/                                                                                     *
 *                                                                                                                    *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES  *
 * OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions     *
 * and limitations under the License.                                                                                 *
 **********************************************************************************************************************/

package com.aws.nosechallenge.local.states;

import android.graphics.Point;
import android.graphics.Rect;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

import com.aws.nosechallenge.MyApplication;
import com.aws.nosechallenge.common.GraphicOverlay;
import com.aws.nosechallenge.local.NoseChallengeOverlay;
import com.google.firebase.ml.vision.common.FirebaseVisionPoint;
import com.google.firebase.ml.vision.face.FirebaseVisionFace;
import com.google.firebase.ml.vision.face.FirebaseVisionFaceLandmark;

import java.util.List;

public class NoseState extends State {

    private static final String LOG_TAG = "Nose/NoseState";

    static final String NAME = "Nose";

    private final int faceTrackingId;
    private final Rect noseChallengeBox;

    NoseState(ViewBinding binding, int faceTrackingId) {
        super(binding);
        this.faceTrackingId = faceTrackingId;
        this.noseChallengeBox = getNoseChallengeBox();
    }

    private Rect getNoseChallengeBox() {
        int left = MyApplication.getConfiguration().getChallengeDetails().getNoseLeft();
        int top = MyApplication.getConfiguration().getChallengeDetails().getNoseTop();
        int right = MyApplication.getConfiguration().getChallengeDetails().getNoseLeft() +
                MyApplication.getConfiguration().getChallengeDetails().getNoseWidth();
        int bottom = MyApplication.getConfiguration().getChallengeDetails().getNoseTop() +
                MyApplication.getConfiguration().getChallengeDetails().getNoseHeight();
        return new Rect(left, top, right, bottom);
    }

    @Override
    public Result process(@NonNull List<FirebaseVisionFace> faces, @NonNull GraphicOverlay graphicOverlay) {
        NoseChallengeOverlay noseChallengeOverlay = new NoseChallengeOverlay(graphicOverlay);
        noseChallengeOverlay.setBinding(getBinding());
        noseChallengeOverlay.setFaceAreaBox(getFaceAreaBox());
        noseChallengeOverlay.setInsideFaceArea(true);
        noseChallengeOverlay.setNoseChallengeBox(noseChallengeBox);
        noseChallengeOverlay.setShowHelpAnimation2(true);
        if (faces.size() == 1) {
            FirebaseVisionFace face = faces.get(0);
            if (faceTrackingId == face.getTrackingId()) {
                noseChallengeOverlay.setFaceBox(face.getBoundingBox());
                FirebaseVisionFaceLandmark visionFaceLandmark = face.getLandmark(FirebaseVisionFaceLandmark.NOSE_BASE);
                if (visionFaceLandmark != null) {
                    FirebaseVisionPoint visionPoint = visionFaceLandmark.getPosition();
                    Point noseLandmark = new Point(visionPoint.getX().intValue(), visionPoint.getY().intValue());
                    noseChallengeOverlay.setNoseLandmark(noseLandmark);
                    int x = MyApplication.getConfiguration().getChallengeDetails().getImageWidth() - noseLandmark.x;
                    int y = noseLandmark.y;
                    Log.d(LOG_TAG, "Nose landmark: x=" + x + " y=" + y);
                    if (noseChallengeBox.contains(x, y)) {  // Success
                        return new Result(noseChallengeOverlay, new SuccessState(getBinding()));
                    }
                }
                noseChallengeOverlay.setMessage(MyApplication.getConfiguration().getStateNoseMessage());
                return new Result(noseChallengeOverlay, this);
            }
        }
        return new Result(noseChallengeOverlay, new FailState(getBinding()));
    }

    @Override
    public int getMaximumDurationInSeconds() {
        return MyApplication.STATE_NOSE_DURATION_IN_SECONDS;
    }

    @Override
    String getName() {
        return NAME;
    }
}
