/**********************************************************************************************************************
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.                                            *
 *                                                                                                                    *
 * Licensed under the Amazon Software License (the "License"). You may not use this file except in compliance         *
 * with the License. A copy of the License is located at                                                              *
 *                                                                                                                    *
 *     http://aws.amazon.com/asl/                                                                                     *
 *                                                                                                                    *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES  *
 * OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions     *
 * and limitations under the License.                                                                                 *
 **********************************************************************************************************************/

package com.aws.nosechallenge.remote;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;

import com.amazonaws.auth.CognitoCredentialsProvider;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.aws.nosechallenge.MyApplication;
import com.aws.nosechallenge.local.Frame;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class VerifyChallengeTask extends AsyncTask<List<Frame>, Void, Boolean> {

    private static final String LOG_TAG = "Nose/VerifyTask";

    private static final String S3_KEY_PATTERN = "%s/%s/%d.jpg";  // {user_id}/{challenge_id}/{frame_timestamp}.jpg
    private static final float FPS_TOLERANCE = 1.1f;

    private final AmazonS3Client s3Client;
    private final OnRemoteChallengeCallback onRemoteChallengeCallback;

    public VerifyChallengeTask(OnRemoteChallengeCallback onRemoteChallengeCallback) {
        CognitoCredentialsProvider credentialsProvider = new CognitoCredentialsProvider(
                MyApplication.IDENTITY_POOL_ID, MyApplication.AWS_REGION);
        this.s3Client = new AmazonS3Client(credentialsProvider);
        this.onRemoteChallengeCallback = onRemoteChallengeCallback;
    }

    @SafeVarargs
    @Override
    protected final Boolean doInBackground(List<Frame>... lists) {
        List<String> s3Keys = uploadImages(lists[0]);
        return callApi(s3Keys);
    }

    private boolean callApi(List<String> s3Keys) {
        String urlString = MyApplication.API_BASE_URL + String.format(MyApplication.API_VERIFY_ENDPOINT_PATTERN,
                MyApplication.getConfiguration().getChallengeDetails().getId());
        Log.d(LOG_TAG, "Request URL: " + urlString);
        try {
            JSONObject jsonObjectRequest = new JSONObject();
            JSONArray jsonArray = new JSONArray(s3Keys);
            jsonObjectRequest.put("frames", jsonArray);
            Log.d(LOG_TAG, "Request: " + jsonObjectRequest.toString());
            String response = HttpUtils.post(urlString, jsonObjectRequest.toString());
            Log.d(LOG_TAG, "Response: " + response);
            JSONObject jsonObjectResponse = new JSONObject(response);
            return jsonObjectResponse.getBoolean("success");
        } catch (Exception ignored) {
        }
        return false;
    }

    @SuppressLint("DefaultLocale")
    private List<String> uploadImages(List<Frame> frames) {
        List<String> s3Keys = new ArrayList<>();
        List<Frame> framesToUpload = dropFrames(frames);
        ExecutorService executorService = Executors.newCachedThreadPool();
        for (Frame frame : framesToUpload) {
            String key = String.format(S3_KEY_PATTERN,
                    MyApplication.USER_ID,
                    MyApplication.getConfiguration().getChallengeDetails().getId(),
                    frame.getTimestamp());
            s3Keys.add(key);
            executorService.execute(new UploadToS3(frame.getImage(), key, s3Client));
        }
        executorService.shutdown();
        try {
            executorService.awaitTermination(MyApplication.S3_UPLOAD_TIMEOUT_IN_MINUTES, TimeUnit.MINUTES);
        } catch (InterruptedException ignored) {
        }
        return s3Keys;
    }

    private List<Frame> dropFrames(List<Frame> frames) {
        Log.d(LOG_TAG, "Upload maximum FPS: " + MyApplication.UPLOAD_MAXIMUM_FPS);
        List<Frame> framesKept = new ArrayList<>();
        framesKept.add(frames.get(0));  // Always keep first and last frames
        framesKept.add(frames.get(frames.size() - 1));
        float fps;
        int previousFrameIndex = 0;
        for (int currentFrameIndex = 1; currentFrameIndex < frames.size() - 1; currentFrameIndex++) {
            fps = 1000f / (frames.get(currentFrameIndex).getTimestamp() - frames.get(previousFrameIndex).getTimestamp());
            Log.d(LOG_TAG, "FPS: " + fps);
            if (fps <= MyApplication.UPLOAD_MAXIMUM_FPS * FPS_TOLERANCE) {
                framesKept.add(frames.get(currentFrameIndex));
                previousFrameIndex = currentFrameIndex;
            } else {
                Log.d(LOG_TAG, "Dropped one frame.");
            }
        }
        Log.d(LOG_TAG, "Original number of frames: " + frames.size());
        Log.d(LOG_TAG, "Number of frames kept: " + framesKept.size());
        return framesKept;
    }

    protected void onPostExecute(Boolean result) {
        if (result) {
            onRemoteChallengeCallback.onBackendChallengeSuccess();
        } else {
            onRemoteChallengeCallback.onBackendChallengeFail();
        }
    }

    private static class UploadToS3 implements Runnable {

        private static final String CONTENT_TYPE = "image/jpeg";

        private final Bitmap image;
        private final String key;
        private final AmazonS3Client s3Client;

        UploadToS3(Bitmap image, String key, AmazonS3Client s3Client) {
            this.image = image;
            this.key = key;
            this.s3Client = s3Client;
        }

        @Override
        public void run() {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            image.compress(Bitmap.CompressFormat.JPEG, MyApplication.JPG_QUALITY, outputStream);
            byte[] bitMapData = outputStream.toByteArray();
            InputStream inputStream = new ByteArrayInputStream(bitMapData);
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentType(CONTENT_TYPE);
            metadata.setContentLength(bitMapData.length);
            PutObjectRequest putObjectRequest = new PutObjectRequest(MyApplication.BUCKET_NAME, key, inputStream, metadata);
            try {
                s3Client.putObject(putObjectRequest);
            } catch (Exception ignored) {
            }
        }
    }
}
