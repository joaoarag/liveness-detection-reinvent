/**********************************************************************************************************************
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.                                            *
 *                                                                                                                    *
 * Licensed under the Amazon Software License (the "License"). You may not use this file except in compliance         *
 * with the License. A copy of the License is located at                                                              *
 *                                                                                                                    *
 *     http://aws.amazon.com/asl/                                                                                     *
 *                                                                                                                    *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES  *
 * OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions     *
 * and limitations under the License.                                                                                 *
 **********************************************************************************************************************/

package com.aws.nosechallenge;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewbinding.ViewBinding;

import com.aws.nosechallenge.common.CameraSource;
import com.aws.nosechallenge.databinding.ActivityMainCameraBinding;
import com.aws.nosechallenge.databinding.ActivityMainLoadingBinding;
import com.aws.nosechallenge.databinding.ActivityMainResultFailBinding;
import com.aws.nosechallenge.databinding.ActivityMainResultSuccessBinding;
import com.aws.nosechallenge.local.Frame;
import com.aws.nosechallenge.local.NoseChallengeProcessor;
import com.aws.nosechallenge.local.OnLocalChallengeCallback;
import com.aws.nosechallenge.remote.OnRemoteChallengeCallback;
import com.aws.nosechallenge.remote.VerifyChallengeTask;

import java.io.IOException;
import java.util.List;


public final class MainActivity extends AppCompatActivity
        implements OnLocalChallengeCallback, OnRemoteChallengeCallback {

    private static final String LOG_TAG = "Nose/MainActivity";

    private CameraSource cameraSource = null;
    private ActivityMainCameraBinding mainCameraBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainCameraBinding = ActivityMainCameraBinding.inflate(getLayoutInflater());
        setContentView(mainCameraBinding.getRoot());
        createCameraSource();
    }

    private void createCameraSource() {
        if (cameraSource == null) {
            cameraSource = new CameraSource(this, mainCameraBinding.graphicOverlay);
        }
        cameraSource.setMachineLearningFrameProcessor(new NoseChallengeProcessor(mainCameraBinding, this));
    }

    private void startCameraSource() {
        if (cameraSource != null) {
            try {
                mainCameraBinding.cameraPreview.start(cameraSource, mainCameraBinding.graphicOverlay);
            } catch (IOException e) {
                Log.e(LOG_TAG, "Unable to start camera source.", e);
                cameraSource.release();
                cameraSource = null;
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        startCameraSource();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mainCameraBinding.cameraPreview.stop();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (cameraSource != null) {
            cameraSource.release();
        }
    }

    @Override
    public void onLocalChallengeSuccess(List<Frame> frames) {
        ActivityMainLoadingBinding binding = ActivityMainLoadingBinding.inflate(getLayoutInflater());
        changeLayout(binding);
        new VerifyChallengeTask(this).execute(frames);
    }

    @Override
    public void onLocalChallengeFail() {
        changeLayoutToFail();
    }

    @Override
    public void onBackendChallengeSuccess() {
        ActivityMainResultSuccessBinding binding = ActivityMainResultSuccessBinding.inflate(getLayoutInflater());
        binding.successButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startWelcomeActivity();
            }
        });
        changeLayout(binding);
    }

    @Override
    public void onBackendChallengeFail() {
        changeLayoutToFail();
    }

    private void changeLayoutToFail() {
        ActivityMainResultFailBinding binding = ActivityMainResultFailBinding.inflate(getLayoutInflater());
        binding.failButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startWelcomeActivity();
            }
        });
        changeLayout(binding);
    }

    private void startWelcomeActivity() {
        Intent intent = new Intent(this, WelcomeActivity.class);
        startActivity(intent);
        finish();
    }

    private void changeLayout(ViewBinding binding) {
        setContentView(binding.getRoot());
        mainCameraBinding.topLayout.setVisibility(View.GONE);
        if (cameraSource != null) {
            cameraSource.release();
        }
    }
}
