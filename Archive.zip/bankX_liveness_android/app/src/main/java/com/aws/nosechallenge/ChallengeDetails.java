/**********************************************************************************************************************
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.                                            *
 *                                                                                                                    *
 * Licensed under the Amazon Software License (the "License"). You may not use this file except in compliance         *
 * with the License. A copy of the License is located at                                                              *
 *                                                                                                                    *
 *     http://aws.amazon.com/asl/                                                                                     *
 *                                                                                                                    *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES  *
 * OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions     *
 * and limitations under the License.                                                                                 *
 **********************************************************************************************************************/

package com.aws.nosechallenge;

import androidx.annotation.NonNull;

import org.json.JSONException;
import org.json.JSONObject;

public class ChallengeDetails {

    private final String id;
    private final int imageWidth;
    private final int imageHeight;
    private final int areaLeft;
    private final int areaTop;
    private final int areaWidth;
    private final int areaHeight;
    private final int noseLeft;
    private final int noseTop;
    private final int noseWidth;
    private final int noseHeight;

    public ChallengeDetails(JSONObject jsonObject) throws JSONException {
        id = jsonObject.getString("id");
        imageWidth = jsonObject.getInt("imageWidth");
        imageHeight = jsonObject.getInt("imageHeight");
        areaLeft = jsonObject.getInt("areaLeft");
        areaTop = jsonObject.getInt("areaTop");
        areaWidth = jsonObject.getInt("areaWidth");
        areaHeight = jsonObject.getInt("areaHeight");
        noseLeft = jsonObject.getInt("noseLeft");
        noseTop = jsonObject.getInt("noseTop");
        noseWidth = jsonObject.getInt("noseWidth");
        noseHeight = jsonObject.getInt("noseHeight");
    }

    public String getId() {
        return id;
    }

    public int getImageWidth() {
        return imageWidth;
    }

    public int getImageHeight() {
        return imageHeight;
    }

    public int getAreaLeft() {
        return areaLeft;
    }

    public int getAreaTop() {
        return areaTop;
    }

    public int getAreaWidth() {
        return areaWidth;
    }

    public int getAreaHeight() {
        return areaHeight;
    }

    public int getNoseLeft() {
        return noseLeft;
    }

    public int getNoseTop() {
        return noseTop;
    }

    public int getNoseWidth() {
        return noseWidth;
    }

    public int getNoseHeight() {
        return noseHeight;
    }

    @NonNull
    @Override
    public String toString() {
        return "ChallengeDetails{" +
                "id='" + id + '\'' +
                ", imageWidth=" + imageWidth +
                ", imageHeight=" + imageHeight +
                ", areaLeft=" + areaLeft +
                ", areaTop=" + areaTop +
                ", areaWidth=" + areaWidth +
                ", areaHeight=" + areaHeight +
                ", noseLeft=" + noseLeft +
                ", noseTop=" + noseTop +
                ", noseWidth=" + noseWidth +
                ", noseHeight=" + noseHeight +
                '}';
    }
}
