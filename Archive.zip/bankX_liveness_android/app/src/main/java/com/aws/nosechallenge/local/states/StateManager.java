/**********************************************************************************************************************
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.                                            *
 *                                                                                                                    *
 * Licensed under the Amazon Software License (the "License"). You may not use this file except in compliance         *
 * with the License. A copy of the License is located at                                                              *
 *                                                                                                                    *
 *     http://aws.amazon.com/asl/                                                                                     *
 *                                                                                                                    *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES  *
 * OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions     *
 * and limitations under the License.                                                                                 *
 **********************************************************************************************************************/

package com.aws.nosechallenge.local.states;

import android.graphics.Bitmap;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

import com.aws.nosechallenge.common.GraphicOverlay;
import com.aws.nosechallenge.local.Frame;
import com.aws.nosechallenge.local.NoseChallengeOverlay;
import com.google.firebase.ml.vision.face.FirebaseVisionFace;

import java.util.ArrayList;
import java.util.List;

public class StateManager {

    private static final String LOG_TAG = "Nose/StateManager";

    private State currentState;
    private long endTime;
    private final ViewBinding binding;
    private List<Frame> frames = new ArrayList<>();

    private boolean done = false;
    private boolean success = false;

    public StateManager(ViewBinding binding) {
        this.binding = binding;
        changeCurrentState(new FaceState(binding));
    }

    public NoseChallengeOverlay process(@NonNull Bitmap originalCameraImage,
                                        @NonNull List<FirebaseVisionFace> faces,
                                        @NonNull GraphicOverlay graphicOverlay) {
        Log.d(LOG_TAG, "Current state: " + currentState.getName());
        Log.d(LOG_TAG, "Seconds left: " + (endTime > 0 ? endTime - System.currentTimeMillis() / 1000 : "n/a"));

        if (endTime > 0 && System.currentTimeMillis() / 1000 > endTime) {
            Log.d(LOG_TAG, "End of time!");
            changeCurrentState(new FailState(binding));
        }
        Result result = currentState.process(faces, graphicOverlay);
        changeCurrentState(result.getNextState());
        switch (currentState.getName()) {
            case NoseState.NAME:
                addFrame(originalCameraImage);
                break;
            case SuccessState.NAME:
                addFrame(originalCameraImage);
                done = true;
                success = true;
                break;
            case FailState.NAME:
                done = true;
                success = false;
                break;
        }
        return result.getNoseChallengeOverlay();
    }

    private void addFrame(@NonNull Bitmap originalCameraImage) {
        Frame frame = new Frame(originalCameraImage, System.currentTimeMillis());
        frames.add(frame);
    }

    private void changeCurrentState(State state) {
        if (currentState != state) {
            currentState = state;
            endTime = state.getMaximumDurationInSeconds() != -1 ? System.currentTimeMillis() / 1000 + state.getMaximumDurationInSeconds() : -1;
        }
    }

    public List<Frame> getFrames() {
        return frames;
    }

    public boolean isDone() {
        return done;
    }

    public boolean isSuccess() {
        return success;
    }
}
