/**********************************************************************************************************************
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.                                            *
 *                                                                                                                    *
 * Licensed under the Amazon Software License (the "License"). You may not use this file except in compliance         *
 * with the License. A copy of the License is located at                                                              *
 *                                                                                                                    *
 *     http://aws.amazon.com/asl/                                                                                     *
 *                                                                                                                    *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES  *
 * OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions     *
 * and limitations under the License.                                                                                 *
 **********************************************************************************************************************/

package com.aws.nosechallenge.local.states;

import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;

import com.aws.nosechallenge.MyApplication;
import com.aws.nosechallenge.common.GraphicOverlay;
import com.aws.nosechallenge.local.NoseChallengeOverlay;
import com.google.firebase.ml.vision.face.FirebaseVisionFace;

import java.util.List;

public class FaceState extends State {

    private static final String NAME = "Face";

    FaceState(ViewBinding binding) {
        super(binding);
    }

    @Override
    public Result process(@NonNull List<FirebaseVisionFace> faces, @NonNull GraphicOverlay graphicOverlay) {
        NoseChallengeOverlay noseChallengeOverlay = new NoseChallengeOverlay(graphicOverlay);
        noseChallengeOverlay.setBinding(getBinding());
        noseChallengeOverlay.setFaceAreaBox(getFaceAreaBox());
        noseChallengeOverlay.setShowHelpAnimation1(true);
        State nextState;
        switch (faces.size()) {
            case 0:
                nextState = this;
                noseChallengeOverlay.setMessage(MyApplication.getConfiguration().getStateFaceNoFaceMessage());
                break;
            case 1:  // Success
                FirebaseVisionFace face = faces.get(0);
                noseChallengeOverlay.setFaceBox(face.getBoundingBox());
                nextState = new AreaState(getBinding(), face.getTrackingId());
                break;
            default:
                nextState = this;
                noseChallengeOverlay.setMessage(MyApplication.getConfiguration().getStateFaceMultipleFacesMessage());
        }
        return new Result(noseChallengeOverlay, nextState);
    }

    @Override
    public int getMaximumDurationInSeconds() {
        return MyApplication.STATE_FACE_DURATION_IN_SECONDS;
    }

    @Override
    String getName() {
        return NAME;
    }
}
