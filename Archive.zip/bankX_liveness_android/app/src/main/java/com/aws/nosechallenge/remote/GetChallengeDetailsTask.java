/**********************************************************************************************************************
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.                                            *
 *                                                                                                                    *
 * Licensed under the Amazon Software License (the "License"). You may not use this file except in compliance         *
 * with the License. A copy of the License is located at                                                              *
 *                                                                                                                    *
 *     http://aws.amazon.com/asl/                                                                                     *
 *                                                                                                                    *
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES  *
 * OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions     *
 * and limitations under the License.                                                                                 *
 **********************************************************************************************************************/

package com.aws.nosechallenge.remote;

import android.hardware.Camera;
import android.os.AsyncTask;
import android.util.Log;

import com.aws.nosechallenge.ChallengeDetails;
import com.aws.nosechallenge.MyApplication;
import com.aws.nosechallenge.common.CameraSource;
import com.google.android.gms.common.images.Size;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class GetChallengeDetailsTask extends AsyncTask<Void, Void, ChallengeDetails> {

    private static final String LOG_TAG = "Nose/GetDetailsTask";

    private final OnChallengeDetailsCallback onChallengeDetailsCallback;

    public GetChallengeDetailsTask(OnChallengeDetailsCallback onChallengeDetailsCallback) {
        this.onChallengeDetailsCallback = onChallengeDetailsCallback;
    }

    @Override
    protected final ChallengeDetails doInBackground(Void... v) {
        // width and height are inverted because we use portrait (not landscape)
        Size cameraPreviewSize = getCameraPreviewSize();
        int imageWidth = cameraPreviewSize.getHeight();
        int imageHeight = cameraPreviewSize.getWidth();

        String urlString = MyApplication.API_BASE_URL + MyApplication.API_START_ENDPOINT;
        Log.d(LOG_TAG, "Request URL: " + urlString);
        try {
            JSONObject jsonObjectRequest = new JSONObject();
            jsonObjectRequest.put("userId", MyApplication.USER_ID);
            jsonObjectRequest.put("imageWidth", imageWidth);
            jsonObjectRequest.put("imageHeight", imageHeight);
            Log.d(LOG_TAG, "Request: " + jsonObjectRequest.toString());
            String response = HttpUtils.post(urlString, jsonObjectRequest.toString());
            Log.d(LOG_TAG, "Response: " + response);
            JSONObject jsonObjectResponse = new JSONObject(response);
            return new ChallengeDetails(jsonObjectResponse);
        } catch (Exception ignored) {
        }
        return null;
    }

    private Size getCameraPreviewSize() {
        // width and height are inverted because we use portrait (not landscape)
        int desiredWidth = MyApplication.DESIRED_IMAGE_HEIGHT;
        int desiredHeight = MyApplication.DESIRED_IMAGE_WIDTH;
        Log.d(LOG_TAG, "Desired camera preview size: " + desiredWidth + "x" + desiredHeight);

        int requestedCameraId = CameraSource.getIdForRequestedCamera(Camera.CameraInfo.CAMERA_FACING_FRONT);
        Camera camera = Camera.open(requestedCameraId);
        List<CameraSource.SizePair> validPreviewSizes = CameraSource.generateValidPreviewSizeList(camera);

        // Just for debug message
        List<String> validPreviewSizesString = new ArrayList<>();
        for (CameraSource.SizePair size : validPreviewSizes) {
            validPreviewSizesString.add(size.preview.toString());
        }
        Log.d(LOG_TAG, "Valid camera preview sizes: " + validPreviewSizesString);

        CameraSource.SizePair sizePair = CameraSource.selectSizePair(validPreviewSizes, desiredWidth, desiredHeight);
        Log.d(LOG_TAG, "Selected camera preview size: " + sizePair.preview);

        camera.release();
        return sizePair.preview;
    }

    protected void onPostExecute(ChallengeDetails challengeDetails) {
        if (challengeDetails != null) {
            onChallengeDetailsCallback.onChallengeDetailsSuccessCallback(challengeDetails);
        } else {
            onChallengeDetailsCallback.onChallengeDetailsFailCallback();
        }
    }


}
