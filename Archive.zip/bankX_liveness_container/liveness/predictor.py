# Copyright 2020 Amazon.com and its affiliates; all rights reserved.
# This file is AWS Content and may not be duplicated or distributed
# without permission.

# This is the file that implements a flask server to do inferences. It's the file that you will modify
# to implement the prediction for your own algorithm.
from __future__ import print_function

import os
import uuid
import json
import decimal
from concurrent.futures import ThreadPoolExecutor, as_completed
import flask
import boto3
from flask import Flask, request, jsonify

from states.face import FaceState
from states.nose import NoseState
from states.area import AreaState
from states.manager import StateManager

# The flask app for serving predictions
app = Flask(__name__)

region_name = os.getenv('REGION_NAME')
bucket_name = os.getenv('BUCKET_NAME')

rek = boto3.client('rekognition', region_name=region_name)
ddb = boto3.resource('dynamodb', region_name=region_name)
table = ddb.Table('liveness-challenges')

@app.route('/challenge/start', methods=['POST'])
def start():
    print('POST /challenge/start')
    user_id = request.json['userId']
    image_width = int(request.json['imageWidth'])
    image_height = int(request.json['imageHeight'])
    area_x, area_y, area_w, area_h = AreaState.get_face_area_box(image_width, image_height)
    nose_x, nose_y, nose_w, nose_h = NoseState.get_nose_box(image_width, image_height)
    challenge = {
        'id': str(uuid.uuid1()),
        'userId': user_id,
        'imageWidth': image_width,
        'imageHeight': image_height,
        'areaLeft': int(area_x),
        'areaTop': int(area_y),
        'areaWidth': int(area_w),
        'areaHeight': int(area_h),
        'noseLeft': int(nose_x),
        'noseTop': int(nose_y),
        'noseWidth': int(nose_w),
        'noseHeight': int(nose_h)
    }
    print('challenge: {}'.format(challenge))
    table.put_item(Item=challenge)
    return jsonify(challenge)

@app.route('/challenge/<challenge_id>/verify', methods=['POST'])
def verify(challenge_id):
    print('POST /challenge/{}/verify'.format(challenge_id))
    # Looking up challenge on DynamoDB table
    item = table.get_item(Key={'id': challenge_id})
    if 'Item' not in item:
        return flask.Response(response='\n', status=404, mimetype='application/json')
    challenge = convertItem(item['Item'])
    print('challenge: {}'.format(challenge))
    # Getting frames from request
    frames = request.json['frames']
    print('frames: {}'.format(frames))
    # Invoking Rekognition with parallel threads
    with ThreadPoolExecutor(max_workers=10) as pool:
        futures = [
            pool.submit(
                detect_faces, frame
            ) for frame in frames
        ]
        results = [r.result() for r in as_completed(futures)]
    results.sort(key=get_result_frame)
    # Setting up state manager
    first_state = FaceState(challenge)
    state_manager = StateManager(first_state)
    print('state_manager: {}'.format(state_manager.get_current_state_name()))
    # Processing Rekognition results with state manager
    for result in results:
        print('frame: {}'.format(result['frame']))
        state_manager.process(result['faces'])
        print('state_manager: {}'.format(state_manager.get_current_state_name()))
    # Returning result based on final state
    return_value = {'success': state_manager.get_current_state_name() == "Success"}
    print('return_value: {}'.format(return_value))
    return jsonify(return_value)

def detect_faces(frame_key):
    return {
        'frame': frame_key,
        'faces': rek.detect_faces(
            Attributes=['ALL'],
            Image={
                'S3Object': {
                    'Bucket': bucket_name,
                    'Name': frame_key
                }
            }
        )['FaceDetails']
    }

def get_result_frame(result):
    return result['frame']

def convertItem(item):
    return json.loads(json.dumps(item, cls=DecimalEncoder))

# Helper class to convert a DynamoDB item to JSON.
class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            if o % 1 > 0:
                return float(o)
            else:
                return int(o)
        return super(DecimalEncoder, self).default(o)

# Uncomment for local testing
# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=8080, debug=True, use_reloader=False)
