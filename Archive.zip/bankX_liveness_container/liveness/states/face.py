# Copyright 2020 Amazon.com and its affiliates; all rights reserved.
# This file is AWS Content and may not be duplicated or distributed
# without permission.
import states.area as area

class FaceState():

    STATE_NAME = 'Face'

    MAXIMUM_DURATION_IN_SECONDS = None

    MESSAGE_NO_FACE = 'No face detected. Move closer.'
    MESSAGE_MULTIPLE_FACES = 'More than one face detected'

    def __init__(self, challenge):
        self.challenge = challenge

    def process(self, faces):
        self.message = FaceState.MESSAGE_NO_FACE
        success = False
        if len(faces) == 1:
            self.face = faces[0]
            success = True
        elif len(faces) > 1:
            self.message = FaceState.MESSAGE_MULTIPLE_FACES
        return True if success else None

    def get_next_state_failure(self):
        return None

    def get_next_state_success(self):
        return area.AreaState(self.challenge)
