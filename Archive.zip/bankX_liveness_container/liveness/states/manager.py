# Copyright 2020 Amazon.com and its affiliates; all rights reserved.
# This file is AWS Content and may not be duplicated or distributed
# without permission.

class StateManager:

    def __init__(self, first_state):
        self.change_current_state(first_state)

    def process(self, faces):
        # TODO: Timestamp check
        # if self.end_time and time.time() > self.end_time:
        #     self.change_current_state(self.current_state.get_next_state_failure(original_frame))
        #     return
        success = self.current_state.process(faces)
        if success is not None:
            if success:
                next_state = self.current_state = self.current_state.get_next_state_success()
            else:
                next_state = self.current_state = self.current_state.get_next_state_failure()
            self.change_current_state(next_state)
        return

    def change_current_state(self, state):
        self.current_state = state
        # self.end_time = time.time() + state.MAXIMUM_DURATION_IN_SECONDS if state.MAXIMUM_DURATION_IN_SECONDS else None

    def get_current_state_name(self):
        return self.current_state.STATE_NAME
