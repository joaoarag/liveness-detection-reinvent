# Copyright 2020 Amazon.com and its affiliates; all rights reserved.
# This file is AWS Content and may not be duplicated or distributed
# without permission.

class FailState():

    STATE_NAME = 'Fail'

    MAXIMUM_DURATION_IN_SECONDS = None

    MESSAGE = 'Fail!'

    def process(self, frame):
        return None
