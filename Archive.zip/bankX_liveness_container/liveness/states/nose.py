# Copyright 2020 Amazon.com and its affiliates; all rights reserved.
# This file is AWS Content and may not be duplicated or distributed
# without permission.
import random
import numpy as np

import states.face
import states.fail
import states.success
import states.area

class NoseState():

    STATE_NAME = 'Nose'

    MAXIMUM_DURATION_IN_SECONDS = 10

    NOSE_BOX_SIZE = 20
    NOSE_BOX_CENTER_MIN_DIST = 20
    NOSE_BOX_CENTER_MAX_DIST = 50

    AREA_BOX_TOLERANCE = 0.05
    NOSE_BOX_TOLERANCE = 0.10

    HISTOGRAM_BINS = 4
    MIN_DIST = 0.10
    ROTATION_THRESHOLD = 5.0

    def __init__(self, challenge, original_faces):
        self.challenge = challenge
        self.image_width = challenge['imageWidth']
        self.image_height = challenge['imageHeight']
        # Applying tolerance
        area_width_tolerance = challenge['areaWidth'] * NoseState.AREA_BOX_TOLERANCE
        area_height_tolerance = challenge['areaHeight'] * NoseState.AREA_BOX_TOLERANCE
        self.area_box = (challenge['areaLeft'] - area_width_tolerance,
                         challenge['areaTop'] - area_height_tolerance,
                         challenge['areaWidth'] + 2*area_width_tolerance,
                         challenge['areaHeight'] + 2*area_height_tolerance)
        nose_width_tolerance = challenge['noseWidth'] * NoseState.NOSE_BOX_TOLERANCE
        nose_height_tolerance = challenge['noseHeight'] * NoseState.NOSE_BOX_TOLERANCE
        self.nose_box = (challenge['noseLeft'] - nose_width_tolerance,
                         challenge['noseTop'] - nose_height_tolerance,
                         challenge['noseWidth'] + 2*nose_width_tolerance,
                         challenge['noseHeight'] + 2*nose_height_tolerance)
        self.challenge_in_the_right = challenge['noseLeft'] + NoseState.NOSE_BOX_SIZE/2 > self.image_width/2
        self.original_landmarks = original_faces[0]['Landmarks']

    def process(self, faces):
        face_bounding_box = [
            self.image_width * faces[0]['BoundingBox']['Left'],
            self.image_height * faces[0]['BoundingBox']['Top'],
            self.image_width * faces[0]['BoundingBox']['Width'],
            self.image_height * faces[0]['BoundingBox']['Height']
        ]
        if not states.area.AreaState.is_inside_face_area(self.area_box, face_bounding_box):
            return False

        landmarks = faces[0]['Landmarks']
        print('landmarks: {}'.format(landmarks))

        pose = faces[0]['Pose']
        print('pose: {}'.format(pose))

        if self.is_inside_nose_challenge(landmarks):
            verified = self.verify_challenge(landmarks,
                                             pose,
                                             self.challenge_in_the_right)
            return verified

        return None

    def is_inside_nose_challenge(self, landmarks):
        print('nose_box: {}'.format(self.nose_box))
        for landmark in landmarks:
            if landmark['Type'] == 'nose':
                nose_left = self.image_width * landmark['X']
                nose_top = self.image_height * landmark['Y']
                print('nose: ({}, {})'.format(nose_left, nose_top))
                return (self.nose_box[0] <= nose_left and
                        self.nose_box[1] <= nose_top and
                        self.nose_box[0] + self.nose_box[2] >= nose_left and
                        self.nose_box[1] + self.nose_box[3] >= nose_top)
        return False

    def get_next_state_failure(self):
        return states.fail.FailState()

    def get_next_state_success(self):
        return states.success.SuccessState()

    def verify_challenge(self, current_landmarks, pose, challenge_in_the_right):
        print('original_landmarks: {}'.format(self.original_landmarks))
        print('current_landmarks: {}'.format(current_landmarks))
        original_landmarks_x = [self.image_width * landmark['X'] for landmark in self.original_landmarks]
        original_landmarks_y = [self.image_height * landmark['Y'] for landmark in self.original_landmarks]
        original_histogram, _, _ = np.histogram2d(original_landmarks_x, original_landmarks_y, bins=NoseState.HISTOGRAM_BINS)
        original_histogram = np.reshape(original_histogram, NoseState.HISTOGRAM_BINS**2) / len(original_landmarks_x)

        current_landmarks_x = [self.image_width * landmark['X'] for landmark in current_landmarks]
        current_landmarks_y = [self.image_height * landmark['Y'] for landmark in current_landmarks]
        current_histogram, _, _ = np.histogram2d(current_landmarks_x, current_landmarks_y, bins=NoseState.HISTOGRAM_BINS)
        current_histogram = np.reshape(current_histogram, NoseState.HISTOGRAM_BINS**2) / len(current_landmarks_x)

        dist = np.linalg.norm(original_histogram - current_histogram)

        yaw = pose['Yaw']
        rotated_right = yaw > NoseState.ROTATION_THRESHOLD
        rotated_left = yaw < - NoseState.ROTATION_THRESHOLD
        rotated_face = rotated_left or rotated_right

        print('challenge_in_the_right: {}'.format(challenge_in_the_right))
        print('rotated_right: {}'.format(rotated_right))
        print('rotated_left: {}'.format(rotated_left))
        print('dist: {}'.format(dist))

        if (rotated_right and challenge_in_the_right) or (rotated_left and not challenge_in_the_right):  # Less likely to be fake
            min_dist = NoseState.MIN_DIST * 0.75
            print('min_dist: {}'.format(min_dist))
        elif not rotated_face:
            min_dist = NoseState.MIN_DIST * 1.5
            print('min_dist: {}'.format(min_dist))

        if dist > min_dist:
            return True

        return False

    @staticmethod
    def get_nose_box(width, height):
        nose_width = NoseState.NOSE_BOX_SIZE
        nose_height = NoseState.NOSE_BOX_SIZE
        nose_left = width/2 + (
            random.choice([1, -1]) *
            random.randint(NoseState.NOSE_BOX_CENTER_MIN_DIST,
                           NoseState.NOSE_BOX_CENTER_MAX_DIST)
        ) - nose_width
        nose_top = height/2 + (
            random.choice([1, -1]) *
            random.randint(NoseState.NOSE_BOX_CENTER_MIN_DIST,
                           NoseState.NOSE_BOX_CENTER_MAX_DIST)
        ) - nose_height
        return (nose_left, nose_top, nose_width, nose_height)
