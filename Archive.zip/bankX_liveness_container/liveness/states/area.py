# Copyright 2020 Amazon.com and its affiliates; all rights reserved.
# This file is AWS Content and may not be duplicated or distributed
# without permission.
import states.face
import states.nose

class AreaState():

    AREA_BOX_WIDTH_RATIO = 0.75
    AREA_BOX_HEIGHT_RATIO = 0.75

    STATE_NAME = 'Area'

    MAXIMUM_DURATION_IN_SECONDS = 10

    def __init__(self, challenge):
        self.challenge = challenge
        self.image_width = challenge['imageWidth']
        self.image_height = challenge['imageHeight']
        self.area_box = (challenge['areaLeft'], challenge['areaTop'],
                         challenge['areaWidth'], challenge['areaHeight'])

    def process(self, faces):
        self.faces = faces
        face_bounding_box = [
            self.image_width * self.faces[0]['BoundingBox']['Left'],
            self.image_height * self.faces[0]['BoundingBox']['Top'],
            self.image_width * self.faces[0]['BoundingBox']['Width'],
            self.image_height * self.faces[0]['BoundingBox']['Height']
        ]
        success = AreaState.is_inside_face_area(self.area_box, face_bounding_box)
        return True if success else None

    def get_next_state_failure(self):
        return states.face.FaceState(self.challenge)

    def get_next_state_success(self):
        return states.nose.NoseState(self.challenge, self.faces)

    @staticmethod
    def get_face_area_box(image_width, image_height):
        area_width = image_width * AreaState.AREA_BOX_WIDTH_RATIO
        area_height = image_height * AreaState.AREA_BOX_HEIGHT_RATIO
        area_left = image_width/2 - area_width/2
        area_top = image_height/2 - area_height/2
        return (area_left,
                area_top,
                area_width,
                area_height)

    @staticmethod
    def is_inside_face_area(face_area_box, face_box):
        print('face_area_box: {}'.format(face_area_box))
        print('face_box: {}'.format(face_box))
        return (face_area_box[0] <= face_box[0] and
                face_area_box[1] <= face_box[1] and
                face_area_box[0] + face_area_box[2] >= face_box[0] + face_box[2] and
                face_area_box[1] + face_area_box[3] >= face_box[1] + face_box[3])
