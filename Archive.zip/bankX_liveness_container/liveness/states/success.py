# Copyright 2020 Amazon.com and its affiliates; all rights reserved.
# This file is AWS Content and may not be duplicated or distributed
# without permission.

class SuccessState():

    STATE_NAME = 'Success'

    MAXIMUM_DURATION_IN_SECONDS = None

    MESSAGE = 'Success!'

    def process(self, frame):
        return None
